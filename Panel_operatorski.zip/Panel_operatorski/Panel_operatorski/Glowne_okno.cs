﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Panel_operatorski
{
    

    public partial class Glowne_okno : Form
    {
        
        private Form1 okno_log;
        private int operator_licznik;
        private int max_zacieranie;
        private int now_zacieranie;
        private double cisnienie;
        public Glowne_okno(Form1 okno_logowania)
        {
            InitializeComponent();
            this.okno_log = okno_logowania;
            this.operator_licznik = 0;
            this.max_zacieranie = 100;
            this.now_zacieranie = 0;
            this.cisnienie = 1.0;
        }

        private void Glowne_okno_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }


        private void kliknij_timer_Tick(object sender, EventArgs e)
        {
            this.operator_licznik++;
            if (this.operator_licznik >= 2)
            {
                this.Dispose();
                MessageBox.Show("Czas minal!");
                this.okno_log.Show();
            }
        }

        private void operator_button_Click(object sender, EventArgs e)
        {
            this.operator_licznik = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void zacieranie_trackbar_Scroll(object sender, EventArgs e)
        {

        }

        private void zacieranie_timer_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            this.now_zacieranie += 1 + Convert.ToInt32(this.zacieranie_trackbar.Value/3 * rnd.NextDouble());
            int odejmij = Convert.ToInt32(133 * this.now_zacieranie / this.max_zacieranie);
            if (odejmij >= 100)
            {
                this.zacieranie_timer.Enabled = false;
                this.gotowanie_timer.Enabled = true;
                this.dioda_zacieranie.BackgroundImage = new Bitmap("C:\\Users\\admin\\Desktop\\Panel_operatorski\\czerwony.jpg");
                this.dioda_gotowanie.BackgroundImage = new Bitmap("C:\\Users\\admin\\Desktop\\Panel_operatorski\\zielony.png");
                odejmij = 100;
            }
            this.slupek_picturebox.Height = 133 - odejmij;//wysokosc szraej
        }

        private void slupek_picturebox_Click(object sender, EventArgs e)
        {

        }

        private void Glowne_okno_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.cisnienie_timer.Enabled = true;
            this.zacieranie_timer.Enabled = true;
            this.dioda_zacieranie.BackgroundImage = new Bitmap("C:\\Users\\admin\\Desktop\\Panel_operatorski\\zielony.png");
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void gotowanie_timer_Tick(object sender, EventArgs e)
        {
            if (this.gotowanie_progressbar.Value < 14)//jako 14 godzin
            {
                string wartosc = this.predkosc_textbox.Text;
                if (wartosc == "")
                    wartosc = "0";
                int convertacja = Convert.ToInt32(wartosc);
                if (convertacja<=2)
                    this.gotowanie_progressbar.Value += convertacja;

            }
            else
            {
                DateTime thisDay = DateTime.Today;
                this.gotowanie_timer.Enabled = false;
                this.data_label.Text = thisDay.ToString("D");
                this.data_label.Visible = true;
                this.dioda_fermentacja.BackgroundImage = new Bitmap("C:\\Users\\admin\\Desktop\\Panel_operatorski\\zielony.png");
                this.dioda_gotowanie.BackgroundImage = new Bitmap("C:\\Users\\admin\\Desktop\\Panel_operatorski\\czerwony.jpg");
            }
        }

        private void predkosc_textbox_TextChanged(object sender, EventArgs e)
        {
            ;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void cisnienie_timer_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();
            this.cisnienie += 0.0001 + 0.008 * rnd.NextDouble();
            this.cisnienie_label.Text = String.Format("{0:F2}", this.cisnienie);
            if (this.cisnienie > 2)
            {
                this.cisnienie_timer.Enabled = false;
                DialogResult dialog = MessageBox.Show("Za wysokie cisnienie w beczce!\n Zmniejszyc?","Warning",MessageBoxButtons.YesNo);
                if (dialog == DialogResult.Yes)
                    this.cisnienie -= 1.5;
                this.cisnienie_timer.Enabled = true;
            }
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }
    }
}

﻿
namespace Panel_operatorski
{
    partial class Glowne_okno
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.kliknij_timer = new System.Windows.Forms.Timer(this.components);
            this.zacieranie_timer = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gotowanie_timer = new System.Windows.Forms.Timer(this.components);
            this.cisnienie_timer = new System.Windows.Forms.Timer(this.components);
            this.dioda_zacieranie = new System.Windows.Forms.PictureBox();
            this.dioda_gotowanie = new System.Windows.Forms.PictureBox();
            this.dioda_fermentacja = new System.Windows.Forms.PictureBox();
            this.operator_button = new System.Windows.Forms.Button();
            this.zielony_picturebox = new System.Windows.Forms.PictureBox();
            this.slupek_picturebox = new System.Windows.Forms.PictureBox();
            this.predkosc_textbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.zacieranie_trackbar = new System.Windows.Forms.TrackBar();
            this.start_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.gotowanie_progressbar = new System.Windows.Forms.ProgressBar();
            this.data_label = new System.Windows.Forms.Label();
            this.cisnienie_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dioda_zacieranie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dioda_gotowanie)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dioda_fermentacja)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zielony_picturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slupek_picturebox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zacieranie_trackbar)).BeginInit();
            this.SuspendLayout();
            // 
            // kliknij_timer
            // 
            this.kliknij_timer.Enabled = true;
            this.kliknij_timer.Interval = 50000;
            this.kliknij_timer.Tick += new System.EventHandler(this.kliknij_timer_Tick);
            // 
            // zacieranie_timer
            // 
            this.zacieranie_timer.Interval = 300;
            this.zacieranie_timer.Tick += new System.EventHandler(this.zacieranie_timer_Tick);
            // 
            // timer1
            // 
            this.timer1.Interval = 300;
            // 
            // gotowanie_timer
            // 
            this.gotowanie_timer.Interval = 1000;
            this.gotowanie_timer.Tick += new System.EventHandler(this.gotowanie_timer_Tick);
            // 
            // cisnienie_timer
            // 
            this.cisnienie_timer.Tick += new System.EventHandler(this.cisnienie_timer_Tick);
            // 
            // dioda_zacieranie
            // 
            this.dioda_zacieranie.BackgroundImage = global::Panel_operatorski.Properties.Resources.czerwony;
            this.dioda_zacieranie.Location = new System.Drawing.Point(75, 56);
            this.dioda_zacieranie.Name = "dioda_zacieranie";
            this.dioda_zacieranie.Size = new System.Drawing.Size(54, 40);
            this.dioda_zacieranie.TabIndex = 0;
            this.dioda_zacieranie.TabStop = false;
            // 
            // dioda_gotowanie
            // 
            this.dioda_gotowanie.BackgroundImage = global::Panel_operatorski.Properties.Resources.czerwony;
            this.dioda_gotowanie.Location = new System.Drawing.Point(680, 56);
            this.dioda_gotowanie.Name = "dioda_gotowanie";
            this.dioda_gotowanie.Size = new System.Drawing.Size(54, 40);
            this.dioda_gotowanie.TabIndex = 2;
            this.dioda_gotowanie.TabStop = false;
            // 
            // dioda_fermentacja
            // 
            this.dioda_fermentacja.BackgroundImage = global::Panel_operatorski.Properties.Resources.czerwony;
            this.dioda_fermentacja.Location = new System.Drawing.Point(357, 303);
            this.dioda_fermentacja.Name = "dioda_fermentacja";
            this.dioda_fermentacja.Size = new System.Drawing.Size(55, 40);
            this.dioda_fermentacja.TabIndex = 4;
            this.dioda_fermentacja.TabStop = false;
            this.dioda_fermentacja.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // operator_button
            // 
            this.operator_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.operator_button.Location = new System.Drawing.Point(22, 355);
            this.operator_button.Name = "operator_button";
            this.operator_button.Size = new System.Drawing.Size(156, 69);
            this.operator_button.TabIndex = 5;
            this.operator_button.Text = "KLIKNIJ!";
            this.operator_button.UseVisualStyleBackColor = true;
            this.operator_button.Click += new System.EventHandler(this.operator_button_Click);
            // 
            // zielony_picturebox
            // 
            this.zielony_picturebox.BackgroundImage = global::Panel_operatorski.Properties.Resources.zielony;
            this.zielony_picturebox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.zielony_picturebox.Location = new System.Drawing.Point(85, 118);
            this.zielony_picturebox.Name = "zielony_picturebox";
            this.zielony_picturebox.Size = new System.Drawing.Size(29, 133);
            this.zielony_picturebox.TabIndex = 6;
            this.zielony_picturebox.TabStop = false;
            // 
            // slupek_picturebox
            // 
            this.slupek_picturebox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.slupek_picturebox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slupek_picturebox.Location = new System.Drawing.Point(85, 118);
            this.slupek_picturebox.Name = "slupek_picturebox";
            this.slupek_picturebox.Size = new System.Drawing.Size(29, 133);
            this.slupek_picturebox.TabIndex = 7;
            this.slupek_picturebox.TabStop = false;
            this.slupek_picturebox.Click += new System.EventHandler(this.slupek_picturebox_Click);
            // 
            // predkosc_textbox
            // 
            this.predkosc_textbox.Location = new System.Drawing.Point(646, 139);
            this.predkosc_textbox.Name = "predkosc_textbox";
            this.predkosc_textbox.Size = new System.Drawing.Size(88, 27);
            this.predkosc_textbox.TabIndex = 8;
            this.predkosc_textbox.TextChanged += new System.EventHandler(this.predkosc_textbox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Font = new System.Drawing.Font("Segoe UI Black", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(47, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Zacieranie";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // zacieranie_trackbar
            // 
            this.zacieranie_trackbar.Location = new System.Drawing.Point(47, 257);
            this.zacieranie_trackbar.Name = "zacieranie_trackbar";
            this.zacieranie_trackbar.Size = new System.Drawing.Size(131, 56);
            this.zacieranie_trackbar.TabIndex = 10;
            this.zacieranie_trackbar.Scroll += new System.EventHandler(this.zacieranie_trackbar_Scroll);
            // 
            // start_button
            // 
            this.start_button.Location = new System.Drawing.Point(601, 355);
            this.start_button.Name = "start_button";
            this.start_button.Size = new System.Drawing.Size(158, 69);
            this.start_button.TabIndex = 11;
            this.start_button.Text = "START";
            this.start_button.UseVisualStyleBackColor = true;
            this.start_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("Segoe UI Black", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(601, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 25);
            this.label2.TabIndex = 12;
            this.label2.Text = "Gotowanie brzeczki";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // gotowanie_progressbar
            // 
            this.gotowanie_progressbar.Location = new System.Drawing.Point(601, 188);
            this.gotowanie_progressbar.Maximum = 14;
            this.gotowanie_progressbar.Name = "gotowanie_progressbar";
            this.gotowanie_progressbar.Size = new System.Drawing.Size(133, 29);
            this.gotowanie_progressbar.TabIndex = 13;
            // 
            // data_label
            // 
            this.data_label.AutoSize = true;
            this.data_label.Location = new System.Drawing.Point(373, 379);
            this.data_label.Name = "data_label";
            this.data_label.Size = new System.Drawing.Size(39, 20);
            this.data_label.TabIndex = 14;
            this.data_label.Text = "data";
            this.data_label.Visible = false;
            // 
            // cisnienie_label
            // 
            this.cisnienie_label.AutoSize = true;
            this.cisnienie_label.Font = new System.Drawing.Font("Segoe UI Black", 54.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cisnienie_label.Location = new System.Drawing.Point(298, 94);
            this.cisnienie_label.Name = "cisnienie_label";
            this.cisnienie_label.Size = new System.Drawing.Size(180, 123);
            this.cisnienie_label.TabIndex = 15;
            this.cisnienie_label.Text = "1.0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.Font = new System.Drawing.Font("Segoe UI Black", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(333, 257);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 25);
            this.label3.TabIndex = 16;
            this.label3.Text = "Fermitacja";
            this.label3.Click += new System.EventHandler(this.label3_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "75C";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 293);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 20);
            this.label5.TabIndex = 18;
            this.label5.Text = "Temperatura wody";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(610, 231);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 20);
            this.label6.TabIndex = 19;
            this.label6.Text = "Czas gotowania";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(589, 116);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(189, 20);
            this.label7.TabIndex = 20;
            this.label7.Text = "Predkosc gotowania(<=2!!)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(333, 208);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 20);
            this.label8.TabIndex = 21;
            this.label8.Text = "cisnienie(PPM)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(195, 421);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(197, 20);
            this.label9.TabIndex = 22;
            this.label9.Text = "data rozpoczeczia fermitacji";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(740, 197);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 20);
            this.label10.TabIndex = 23;
            this.label10.Text = "14h";
            // 
            // Glowne_okno
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cisnienie_label);
            this.Controls.Add(this.data_label);
            this.Controls.Add(this.gotowanie_progressbar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.start_button);
            this.Controls.Add(this.zacieranie_trackbar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.predkosc_textbox);
            this.Controls.Add(this.slupek_picturebox);
            this.Controls.Add(this.zielony_picturebox);
            this.Controls.Add(this.operator_button);
            this.Controls.Add(this.dioda_fermentacja);
            this.Controls.Add(this.dioda_gotowanie);
            this.Controls.Add(this.dioda_zacieranie);
            this.Name = "Glowne_okno";
            this.Text = "Glowne_okno";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Glowne_okno_FormClosing);
            this.Load += new System.EventHandler(this.Glowne_okno_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dioda_zacieranie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dioda_gotowanie)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dioda_fermentacja)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zielony_picturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slupek_picturebox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zacieranie_trackbar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer kliknij_timer;
        private System.Windows.Forms.Timer zacieranie_timer;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer gotowanie_timer;
        private System.Windows.Forms.Timer cisnienie_timer;
        private System.Windows.Forms.PictureBox dioda_zacieranie;
        private System.Windows.Forms.PictureBox dioda_gotowanie;
        private System.Windows.Forms.PictureBox dioda_fermentacja;
        private System.Windows.Forms.Button operator_button;
        private System.Windows.Forms.PictureBox zielony_picturebox;
        private System.Windows.Forms.PictureBox slupek_picturebox;
        private System.Windows.Forms.TextBox predkosc_textbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TrackBar zacieranie_trackbar;
        private System.Windows.Forms.Button start_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar gotowanie_progressbar;
        private System.Windows.Forms.Label data_label;
        private System.Windows.Forms.Label cisnienie_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}
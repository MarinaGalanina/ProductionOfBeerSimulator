﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Panel_operatorski
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        //ustawienia logina i hasła.Jak w tekstboxie login-marina i w hasle-1234-przechodzi do okna glownego i chowa to.Nie-message
        private void zaloguj_button_Click(object sender, EventArgs e)
        {
            string login = this.login_textbox.Text;
            string haslo = this.haslo_textbox.Text;
            if(login=="marina" & haslo == "1234")
            {
                Glowne_okno okno = new Glowne_okno(this);
                okno.Show();
                this.Hide();
                this.login_textbox.Text = "";
                this.haslo_textbox.Text = "";
            }
            else
            {
                MessageBox.Show("Bledy login lub haslo");
               
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
